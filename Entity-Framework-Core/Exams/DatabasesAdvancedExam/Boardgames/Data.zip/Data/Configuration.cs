﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-RT0PP11\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
