﻿namespace P01_StudentSystem.Data.Models.Enums
{
    public enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }
}
