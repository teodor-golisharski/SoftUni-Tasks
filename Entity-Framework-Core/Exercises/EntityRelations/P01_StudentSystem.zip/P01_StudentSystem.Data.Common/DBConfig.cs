﻿namespace P01_StudentSystem.Data.Common
{
    public static class DBConfig
    {
        public const string ConnectionString =
            @"Server=DESKTOP-RT0PP11\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}