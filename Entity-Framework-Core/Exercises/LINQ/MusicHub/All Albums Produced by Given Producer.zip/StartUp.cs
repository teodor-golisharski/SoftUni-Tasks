﻿namespace MusicHub
{
    using System;
    using System.Text;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            Console.WriteLine(ExportAlbumsInfo(context, 9)); ;
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            StringBuilder sb = new StringBuilder();

            var albums = context.Albums
                .Where(a => a.ProducerId == producerId)
                .ToArray();

            foreach (var item in albums.OrderByDescending(a => a.Price))
            {
                sb.AppendLine($"-AlbumName: {item.Name}");
                sb.AppendLine($"-ReleaseDate: {item.ReleaseDate.ToString("MM/dd/yyyy")}");
                sb.AppendLine($"-ProducerName: {item.Producer!.Name}");
                
                sb.AppendLine($"-Songs:");

                int count = 1;

                foreach (var song in item.Songs.OrderByDescending(s => s.Name).ThenBy(w => w.Writer))
                {
                    sb.AppendLine($"---#{count}");
                    sb.AppendLine($"---SongName: {song.Name}");
                    sb.AppendLine($"---Price: {song.Price:f2}");
                    sb.AppendLine($"---Writer: {song.Writer!.Name}");

                    count++;
                }

                sb.AppendLine($"-AlbumPrice: {item.Price:f2}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
