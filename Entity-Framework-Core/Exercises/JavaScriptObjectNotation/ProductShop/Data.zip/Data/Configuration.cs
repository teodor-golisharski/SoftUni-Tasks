﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-RT0PP11\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}
