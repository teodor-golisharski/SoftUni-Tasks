const baseUrl = 'http://localhost:3030/jsonstore/tasks';

const loadButton = document.getElementById('load-meals');
const mealList = document.getElementById('list');

loadButton.addEventListener('click', (e) => {
    fetch(baseUrl)
        .then(res => res.json())
        .then(result => {
            renderMeals(Object.values(result));
        });
    
    
})

function renderMeals(meals){
    meals
    .map(meal = renderMeal)
    .forEach(mealElement => mealList.appendChild(mealElement));
}

function renderMeal(meal){
    const container = document.createElement('div');
    container.className = 'meal';

    const h2Element = document.createElement('h2');
    h2Element.textContent = meal.food;
    const h3TimeElement = document.createElement('h3');
    h3TimeElement.textContent = meal.time;
    const h3CalElement = document.createElement('h3');
    h3CalElement.textContent = meal.calories;

    const innerDiv = document.createElement('div');
    innerDiv.id = 'meal-buttons';
    const changeButton = document.createElement('button');
    changeButton.className = 'change-meal';
    changeButton.textContent = 'Change';
    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-meal';
    deleteButton.textContent = 'Delete';
    
    innerDiv.appendChild(changeButton);
    innerDiv.appendChild(deleteButton);

    container.appendChild(h2Element);
    container.appendChild(h3TimeElement);
    container.appendChild(h3CalElement);
    container.appendChild(innerDiv);
    
    return container;
}