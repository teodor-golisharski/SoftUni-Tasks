﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoxOfString
{
    public class Box<T>
    {
        public Box()
        {
            data = new List<T>();
        }

        private List<T> data;
        
        public List<T> Data 
        { 
            get { return data; }
            set { data = value; }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (var item in data)
            {
                sb.AppendLine($"{typeof(T)}: {item}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
