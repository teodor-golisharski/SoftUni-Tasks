﻿using System;

namespace BoxOfString
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Box<string> box = new Box<string>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();
                box.Data.Add(input);
            }
            string[] s = Console.ReadLine().Split();
            int index1 = int.Parse(s[0]);
            int index2 = int.Parse(s[1]);
            box.Swap(index1, index2);
            Console.WriteLine(box);
        }
    }
}
