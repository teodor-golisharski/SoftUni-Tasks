﻿using System;

namespace Tuple
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] personInfo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            
            string[] drinkInfo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            string[] numInfo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
                      
            Tuple<string, string> tuple1 = new Tuple<string, string>
            {
                Item1 = personInfo[0] + " " + personInfo[1],
                Item2 = personInfo[2]
            };

            Tuple<string, string> tuple2 = new Tuple<string, string>
            {
                Item1 = drinkInfo[0],
                Item2 = drinkInfo[1]
            };

            Tuple<string, string> tuple3 = new Tuple<string, string>
            {
                Item1 = numInfo[0],
                Item2 = numInfo[1]
            };

            Console.WriteLine(tuple1);
            Console.WriteLine(tuple2);
            Console.WriteLine(tuple3);
        }
    }
}
