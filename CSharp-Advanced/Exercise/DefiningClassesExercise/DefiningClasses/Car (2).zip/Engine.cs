﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace DefiningClasses
{
    public class Engine
    {
		private int speed;

		public Engine(int speed, int power)
		{
			this.Speed = speed;
			this.Power = power;
		}
		public int Speed
		{
			get { return speed; }
			set { speed = value; }
		}

		private int power;

		public int Power
		{
			get { return power; }
			set { power = value; }
		}

	}
}
