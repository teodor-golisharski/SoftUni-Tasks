﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Car> cars = new List<Car>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] carInput = Console.ReadLine().Split(' ',
                    StringSplitOptions.RemoveEmptyEntries);

                string model = carInput[0];

                int speed = int.Parse(carInput[1]);

                int power = int.Parse(carInput[2]);

                int weight = int.Parse(carInput[3]);

                string type = carInput[4];

                //Tires
                List<Tire> tires = new List<Tire>();
                for (int j = 0; j < 4; j++)
                {
                    double tirePressure = double.Parse(carInput[5 + (j * 2)]);
                    int tireAge = int.Parse(carInput[6 + (j * 2)]);
                    Tire tire = new Tire(tireAge, tirePressure);
                    tires.Add(tire);
                }

                Engine engine = new Engine(speed, power);
                Cargo cargo = new Cargo(type, weight);

                Car car = new Car(model, engine, cargo, tires);

                cars.Add(car);
            }
            string command = Console.ReadLine();

            if (command == "fragile")
            {
                foreach (var item in cars.Where(x => x.Cargo.Type == "fragile"))
                {
                    if (item.Tires.Any(x => x.Pressure < 1))
                    {
                        Console.WriteLine(item.Model);
                    }
                }
            }
            else if (command == "flammable")
            {
                foreach (var item in cars.Where(x => x.Cargo.Type == "flammable"))
                {
                    if (item.Engine.Power > 250)
                    {
                        Console.WriteLine(item.Model);
                    }
                }
            }
        }
    }
}
