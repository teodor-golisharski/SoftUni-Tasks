﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Engine> engines = new List<Engine>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] engineData = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);

                //Model
                string model = engineData[0];

                //Power
                int power = int.Parse(engineData[1]);

                Engine engine = new Engine(model, power);

                //Count of engineData
                int engineDataCount = engineData.Length;

                //Displacement
                if (engineDataCount == 3)
                {
                    try
                    {
                        int displacement = int.Parse(engineData[2]);
                        engine.Displacement = displacement;
                    }
                    catch(Exception)
                    {
                        string efficiency = engineData[2];
                        engine.Efficiency = efficiency;
                    }

                }

                //Efficiency
                else if (engineDataCount == 4)
                {
                    int displacement = int.Parse(engineData[2]);
                    engine.Displacement = displacement;
                    string efficiency = engineData[3];
                    engine.Efficiency = efficiency;
                }
                engines.Add(engine);
            }

            int m = int.Parse(Console.ReadLine());

            for (int i = 0; i < m; i++)
            {
                string[] carData = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string model = carData[0];
                string engineInput = carData[1];
                Engine engine = engines.Find(x => x.Model == engineInput);
                Car car = new Car(model, engine);

                int carDataCount = carData.Length;
                
                if (carDataCount == 3)
                {
                    try
                    {
                        int weight = int.Parse(carData[2]);
                        car.Weight = weight;
                    }
                    catch (Exception)
                    {
                        string color = carData[2];
                        car.Color = color;
                    }
                    
                }
                else if (carDataCount == 4)
                {
                    int weight = int.Parse(carData[2]);
                    car.Weight = weight;
                    string color = carData[3];
                    car.Color = color;
                }
                Console.WriteLine(car);
            }
        }
    }
}
