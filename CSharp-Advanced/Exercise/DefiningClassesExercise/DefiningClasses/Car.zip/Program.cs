﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            
            List<Car> cars = new List<Car>();
            
            for (int i = 0; i < n; i++)
            {
                string[] carInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string model = carInfo[0];
                double fuelAmount = double.Parse(carInfo[1]);
                double fuelConsumption = double.Parse(carInfo[2]);
                Car car = new Car(model, fuelAmount, fuelConsumption);
                if (!cars.Any(x => x.Model == model))
                {
                    cars.Add(car);
                }

            }
            string command = Console.ReadLine();
            while (command != "End")
            {
                string[] tokens = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string model = tokens[1];
                double km = double.Parse(tokens[2]);

                Car driven = cars.Where(x => x.Model == model).ToList().First();

                driven.Drive(km);

                command = Console.ReadLine();
            }
            foreach (var item in cars)
            {
                Console.WriteLine($"{item.Model} {item.FuelAmount:f2} {item.TravelledDistance}");
            }
        }
    }
}
