﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {

        [Test]
        public void DummyLosesHealthWhenAttacked()
        {
            Dummy dummy = new Dummy(10, 10);
            dummy.TakeAttack(2);
            Assert.That(dummy.Health, Is.EqualTo(8));
        }

        [Test]
        public void DeadDummyException()
        {
            Dummy dummy = new Dummy(0, 10);
            
            Assert.Catch<InvalidOperationException>(() =>
            {
                dummy.TakeAttack(10);
            });
        }

        [Test]
        public void DeadDummyCanGiveXP()
        {
            int experience = 15;
            Dummy dummy = new Dummy(0, experience);

            Assert.AreEqual(experience, dummy.GiveExperience());
        }

        [Test]
        public void AliveDummyCantGiveXP()
        {
            int experience = 15;
            Dummy dummy = new Dummy(10, experience);

            Assert.Catch<InvalidOperationException>(() =>
            {
                dummy.GiveExperience();
            });
        }
    }
}