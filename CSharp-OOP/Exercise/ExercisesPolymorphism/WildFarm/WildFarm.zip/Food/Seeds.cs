﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Food
{
    class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
