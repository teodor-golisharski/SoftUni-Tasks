﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    class Truck : Vehicle
    {
        public Truck(double fuealQuantity, double fuelConsumption) : base(fuealQuantity, fuelConsumption)
        {
            FuelConsumption += 1.6;
        }

        public override void Refuel(double fuel)
        {
            FuelQuanity += (fuel * 0.95);
        }
    }
}
