﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    abstract class Vehicle
    {
        public Vehicle(double fuealQuantity, double fuelConsumption)
        {
            this.FuelQuanity = fuealQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double FuelQuanity { get; set; }
        public double FuelConsumption { get; set; }


        public void Drive(double distance)
        {
            if (FuelConsumption * distance < FuelQuanity)
            {
                FuelQuanity -= FuelConsumption * distance;
                Console.WriteLine($"{this.GetType().Name} travelled {distance} km");
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} needs refueling");
            }
        }

        public abstract void Refuel(double fuel);

        public override string ToString()
        {
            return $"{this.GetType().Name}: {FuelQuanity:f2}";
        }
    }
}
