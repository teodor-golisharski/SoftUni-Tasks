﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    class Car : Vehicle
    {
        public Car(double fuealQuantity, double fuelConsumption) : base(fuealQuantity, fuelConsumption)
        {
            FuelConsumption = fuelConsumption + 0.9;
        }

        public override void Refuel(double fuel)
        {
            FuelQuanity += fuel;
        }
    }
}
