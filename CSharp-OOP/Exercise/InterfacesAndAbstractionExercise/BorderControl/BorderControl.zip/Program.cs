﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> list = new List<IIdentifiable>();
            
            string input = Console.ReadLine();
            IIdentifiable identifiable = null;
            while (input != "End")
            {
                string[] tokens = input.Split(' ');
                if(tokens.Length == 2)
                {
                    identifiable = new Robot(tokens[0], tokens[1]);
                    list.Add(identifiable);
                }
                else if(tokens.Length == 3)
                {
                    identifiable = new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2]);
                    list.Add(identifiable);
                }
                input = Console.ReadLine();
            }
            string validation = Console.ReadLine();
            foreach (var item in list.Where(x => x.Id.EndsWith(validation)))
            {
                Console.WriteLine(item.Id);
            }
        }
    }
}
