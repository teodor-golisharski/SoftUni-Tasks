﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IBirthdate> list = new List<IBirthdate>();
            
            string input = Console.ReadLine();
            
            IBirthdate birthdate = null;
            
            while (input != "End")
            {
                string[] tokens = input.Split(' ');
 
                if (tokens.Length == 3 && tokens[0] == "Pet")
                {
                    birthdate = new Pet(tokens[1], tokens[2]);
                    list.Add(birthdate);
                }
                else if(tokens.Length == 5)
                {
                    birthdate = new Citizen(tokens[1], int.Parse(tokens[2]), tokens[3], tokens[4]);
                    list.Add(birthdate);
                }
                input = Console.ReadLine();
            }
            string validation = Console.ReadLine();
            foreach (var item in list.Where(x => x.Birthdate.EndsWith(validation)))
            {
                Console.WriteLine(item.Birthdate);
            }
        }
    }
}
