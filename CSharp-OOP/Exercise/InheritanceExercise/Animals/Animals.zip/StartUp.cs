﻿using System;

namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string type = Console.ReadLine();
            while(type != "Beast!")
            {
                string[] furtherInformation = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);
                
                string name = furtherInformation[0];
                int age = int.Parse(furtherInformation[1]);
                string gender = furtherInformation[2];
                try
                {
                    switch (type)
                    {
                        case "Cat":
                            Cat cat = new Cat(name, age, gender);
                            Console.WriteLine(cat);
                            break;

                        case "Dog":
                            Dog dog = new Dog(name, age, gender);
                            Console.WriteLine(dog);
                            break;

                        case "Frog":
                            Frog frog = new Frog(name, age, gender);
                            Console.WriteLine(frog);
                            break;

                        case "Kitten":
                            Kitten kitten = new Kitten(name, age, gender);
                            Console.WriteLine(kitten);
                            break;

                        case "Tomcat":
                            Tomcat tomcat = new Tomcat(name, age, gender);
                            Console.WriteLine(tomcat);
                            break;
                    }
                }
                catch(ArgumentException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                type = Console.ReadLine();
            }
        }
    }
}
